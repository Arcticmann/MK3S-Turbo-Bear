# This HAL is for...

  - STM32F407 MCU with STM32Generic Arduino core by danieleff.
  - STM32F765 board "The Borg" with STM32Generic.

See the `README.md` files in HAL_STM32F4 and HAL_STM32F7 for the specifics of those hals.
