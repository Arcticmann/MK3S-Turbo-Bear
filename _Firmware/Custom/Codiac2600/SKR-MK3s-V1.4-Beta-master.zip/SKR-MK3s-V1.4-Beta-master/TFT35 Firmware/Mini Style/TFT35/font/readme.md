the "byte.fon" is the bitmap fonts of ASCII

the "word.fon" is the bitmap fonts of GBK

"byte.fon" fonts size: 12*24

"word.fon" fonts size: 24*24

Scan direction: form UP to DOWN, from LEFT to RIGHT